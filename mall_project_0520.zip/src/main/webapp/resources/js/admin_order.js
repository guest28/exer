/**
 * 
 */
function go_order_save() {
	
	var count = 0;
	if(documnet.frm.result.length == undefined) {
		
		if(document.frm.result.checked == true) {
			
			count++;
		}
	} else {
		
		
	}
	
	
}